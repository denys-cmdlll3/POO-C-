#include "juego21.h"

int main() {
    Juego juego;
    juego.jugar();
    return 0;
}
