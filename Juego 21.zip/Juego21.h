#ifndef JUEGO21_H
#define JUEGO21_H

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Mazo {
    int cartas[52];
    int siguiente = 0;
    string palos[4] = {"Corazones", "Diamantes", "Treboles", "Espadas"};

public:
    Mazo() { barajar(); }
    void setPalos(const string p[4]);
    void barajar();
    int sacar();
    int valor(int carta) const { return carta % 13 + 1; }
    string nombre(int carta) const;
};

class Participante {
protected:
    string nombre;
    int suma = 0;

public:
    Participante(string n) : nombre(n) {}
    virtual ~Participante() {}
    virtual bool quierePedir(int objetivo) = 0;   // cada tipo decide distinto

    void recibir(int valor) { suma += valor; }
    int getSuma() const { return suma; }
    string getNombre() const { return nombre; }
};

class Humano : public Participante {
public:
    Humano(string n) : Participante(n) {}
    bool quierePedir(int objetivo) override;
};

class Computadora : public Participante {
public:
    Computadora(string n) : Participante(n) {}
    bool quierePedir(int objetivo) override { return suma < objetivo - 5; }
};

class Juego {
    Mazo mazo;
    vector<Participante*> jugadores;
    int objetivo = 21;

    void cargarConfiguracion();
    void mostrarResultados();

public:
    Juego() { cargarConfiguracion(); }
    ~Juego();
    void jugar();
};

#endif
