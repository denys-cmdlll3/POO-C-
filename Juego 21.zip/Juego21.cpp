#include "juego21.h"
#include <fstream>
#include <algorithm>
#include <random>

void Mazo::setPalos(const string p[4]) {
    for (int i = 0; i < 4; i++) palos[i] = p[i];
}

void Mazo::barajar() {
    for (int i = 0; i < 52; i++) cartas[i] = i;
    random_device rd;
    mt19937 g(rd());
    shuffle(cartas, cartas + 52, g);
    siguiente = 0;
}

int Mazo::sacar() {
    if (siguiente == 52) barajar();
    return cartas[siguiente++];
}

string Mazo::nombre(int carta) const {
    int v = valor(carta);
    string n = to_string(v);
    if (v == 1) n = "As";
    else if (v == 11) n = "J";
    else if (v == 12) n = "Q";
    else if (v == 13) n = "K";
    return n + " de " + palos[carta / 13];
}

bool Humano::quierePedir(int objetivo) {
    int r;
    cout << "Tu suma: " << suma << " (objetivo " << objetivo
         << "). Otra carta? (1 = si, 0 = no): ";
    cin >> r;
    return r == true;
}

void Juego::cargarConfiguracion() {
    int n = 2;
    string palos[4] = {"Corazones", "Diamantes", "Treboles", "Espadas"};

    ifstream archivo("Archivo.txt");
    if (archivo.is_open()) {
        archivo >> n;
        for (int i = 0; i < 4; i++) archivo >> palos[i];
        archivo >> objetivo;
        cout << "Configuracion cargada desde Archivo.txt\n";
    } else {
        cout << "No se encontro Archivo.txt, se usa la configuracion por defecto.\n";
    }
    if (n < 1) n = 2;

    mazo.setPalos(palos);
    jugadores.push_back(new Humano("Jugador 1"));
    for (int i = 2; i <= n; i++)
        jugadores.push_back(new Computadora("Jugador " + to_string(i)));
}

void Juego::jugar() {
    cout << "\n=== JUEGO "<< objetivo << ", "<< jugadores.size() << " jugadores) ===\n";

    for (Participante* p : jugadores) {
        cout << "\n--- Turno de " << p->getNombre() << " ---\n";
        while (p->getSuma() < objetivo && p->quierePedir(objetivo)) {
            int carta = mazo.sacar();
            p->recibir(mazo.valor(carta));
            cout << "  Carta: " << mazo.nombre(carta) << endl;
        }
        if (p->getSuma() > objetivo) cout << "  Se paso con " << p->getSuma() << "!\n";
    }
    mostrarResultados();
}

void Juego::mostrarResultados() {
    cout << "\n=== RESULTADO FINAL ===\n";
    Participante* ganador = nullptr;

    for (Participante* p : jugadores) {
        cout << p->getNombre() << ": " << p->getSuma() << " puntos\n";
        if (p->getSuma() <= objetivo && (!ganador || p->getSuma() > ganador->getSuma()))
            ganador = p;
    }

    if (ganador)
        cout << "\nEL GANADOR ES: " << ganador->getNombre()
             << " con " << ganador->getSuma() << " puntos!\n";
    else
        cout << "\nNadie gana: todos se pasaron.\n";
}

Juego::~Juego() {
    for (Participante* p : jugadores) delete p;
}
